# -*- coding: utf-8 -*-
"""
Experiments for the reviewer responses:
  Part A: weight sensitivity of Eq. (4)  -> Table RX data
  Part B: convergence curves + kernel evolution -> Fig. RX
  Part C: noise statistics comparison (pool vs source residuals vs i.i.d. Gaussian)
"""
import json
import os

import cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from rwdm import KernelGANTrainer, extract_noise_patches

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, 'experiments')
os.makedirs(OUT, exist_ok=True)

IMG_PATH = os.path.join(ROOT, 'UCMerced_Airplane_20_x2_100.png')
IMG2_PATH = os.path.join(ROOT,
    'GF1B_PMS_E12.3_N45.2_20230214_L1A1228256104-MUX_r14_c07_preview_216_x4_100.png')
K_SIZE, SCALE, CROP = 13, 4, 96


def load_gray(path):
    img = cv2.cvtColor(cv2.imread(path), cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    return cv2.cvtColor(img, cv2.COLOR_RGB2GRAY).astype(np.float32)


def kernel_metrics(k, k_ref, hist):
    ring = np.ones_like(k); ring[2:-2, 2:-2] = 0
    bm = float((k * ring).sum())
    ent = float(-(k[k > 0] * np.log(k[k > 0])).sum())
    ncc = float((k * k_ref).sum() /
                (np.sqrt((k ** 2).sum() * (k_ref ** 2).sum()) + 1e-12))
    rec = float(np.mean(hist['rec'][-100:]))
    dr = float(np.mean(hist['d_real'][-100:]))
    df = float(np.mean(hist['d_fake'][-100:]))
    return dict(boundary_mass=round(bm, 4), entropy=round(ent, 3),
                ncc_vs_default=round(ncc, 4), rec_final=round(rec, 4),
                d_real=round(dr, 3), d_fake=round(df, 3))


def run_cfg(gray, w_rec, w_sum, w_bound, w_adv, n_iter, tag):
    tr = KernelGANTrainer(gray, k_size=K_SIZE, scale=SCALE, crop=CROP,
                          n_iter=n_iter, w_rec=w_rec, w_sum=w_sum,
                          w_bound=w_bound, w_adv=w_adv, device='cpu')
    k = tr.train(verbose=False)
    print(f'  [{tag}] done  bm={float((k*np.pad(np.ones((9,9)),2)) .sum() if False else 0):.4f}',
          flush=True)
    return k, tr.history


# ---------------- Part B first: default @3000 with snapshots (Fig. RX) ----
print('=== Part B: default run @3000 with snapshots ===', flush=True)
gray = load_gray(IMG_PATH)
trB = KernelGANTrainer(gray, k_size=K_SIZE, scale=SCALE, crop=CROP,
                       n_iter=3000, device='cpu')
k_def = trB.train(verbose=True)
snaps = trB.history['snapshots']
np.save(os.path.join(OUT, 'kernel_default_3000.npy'), k_def)

# figure: loss curves + kernel evolution
want = [1, 200, 600, 1200, 2000, 3000]
snap_map = {it: k for it, k in snaps}
snap_map[1] = snaps[0][1] if snaps and snaps[0][0] != 1 else snap_map.get(1)
iters_avail = sorted(snap_map)
picked = []
for w in want:
    it = min(iters_avail, key=lambda x: abs(x - w))
    picked.append(it)

fig = plt.figure(figsize=(11, 6.2))
gs = fig.add_gridspec(2, 6, height_ratios=[1, 1.15], hspace=0.35)
vmax = max(snap_map[it].max() for it in picked)
for j, it in enumerate(picked):
    ax = fig.add_subplot(gs[0, j])
    ax.imshow(snap_map[it], cmap='viridis', vmin=0, vmax=vmax)
    ax.set_title(f'iter {it}', fontsize=9)
    ax.axis('off')
ax1 = fig.add_subplot(gs[1, :3])
h = trB.history
ax1.plot(h['rec'], label='low-freq preservation')
ax1.plot(h['sum'], label='sum-to-one')
ax1.plot(h['bound'], label='boundary penalty')
ax1.set_xlabel('iteration'); ax1.set_title('Constraint terms of Eq. (4)')
ax1.legend(); ax1.grid(alpha=.3)
ax2 = fig.add_subplot(gs[1, 3:])
ax2.plot(h['adv'], label='adversarial')
ax2.plot(h['d_real'], label='D(real)')
ax2.plot(h['d_fake'], label='D(fake)')
ax2.set_xlabel('iteration'); ax2.set_title('Discriminator consistency')
ax2.legend(); ax2.grid(alpha=.3)
fig.suptitle('Kernel estimation: loss curves and kernel evolution (UCMerced airplane, x4)')
fig.savefig(os.path.join(OUT, 'fig_RX_convergence_evolution.png'), dpi=300,
            bbox_inches='tight')
plt.close(fig)
print('Part B figure saved.', flush=True)

# ---------------- Part A: weight sensitivity (Table RX) ----------------
print('=== Part A: weight sensitivity @2000 ===', flush=True)
DEFAULT = dict(w_rec=5.0, w_sum=0.2, w_bound=0.1, w_adv=0.05)
configs = [('default (5.0/0.2/0.1/0.05)', DEFAULT)]
for name, key in [('lambda_lf', 'w_rec'), ('lambda_sum', 'w_sum'),
                  ('lambda_bm', 'w_bound'), ('lambda_adv', 'w_adv')]:
    for f in (0.5, 1.5):
        c = dict(DEFAULT); c[key] = DEFAULT[key] * f
        configs.append((f'{name} x{f} ({c[key]:g})', c))
c = dict(DEFAULT); c['w_rec'] = 0.0; configs.append(('lambda_lf = 0', c))
c = dict(DEFAULT); c['w_bound'] = 0.0; configs.append(('lambda_bm = 0', c))

results = {}
k_base = None
for tag, cfg in configs:
    k, hist = run_cfg(gray, cfg['w_rec'], cfg['w_sum'], cfg['w_bound'],
                      cfg['w_adv'], 2000, tag)
    results[tag] = dict(kernel=k, history=hist)
    if tag.startswith('default'):
        k_base = k
table = {}
for tag, r in results.items():
    table[tag] = kernel_metrics(r['kernel'], k_base, r['history'])
    print(f'  {tag:36s} {table[tag]}', flush=True)
with open(os.path.join(OUT, 'table_RX_weight_sensitivity.json'), 'w') as f:
    json.dump(table, f, indent=2)
print('Part A table saved.', flush=True)

# ---------------- Part C: noise statistics ----------------
print('=== Part C: noise statistics ===', flush=True)

def lag_autocorr(resid, max_lag=8):
    """mean |corr| between residual and its shifted self, lags 1..max_lag."""
    out = []
    r = resid - resid.mean()
    denom = (r ** 2).sum() + 1e-12
    for lag in range(1, max_lag + 1):
        ch = (r[:, :-lag] * r[:, lag:]).sum() / denom
        cv = (r[:-lag, :] * r[lag:, :]).sum() / denom
        out.append(float((abs(ch) + abs(cv)) / 2))
    return out

def patch_residuals(gray, patch=64, stride=32):
    H, W = gray.shape
    res = []
    for y in range(0, H - patch + 1, stride):
        for x in range(0, W - patch + 1, stride):
            p = gray[y:y + patch, x:x + patch]
            res.append(p - p.mean())
    return np.array(res)

stats = {}
fig, axes = plt.subplots(2, 2, figsize=(10, 6.4))
for row, (name, path) in enumerate([('UCMerced airplane', IMG_PATH),
                                    ('GF1B farmland', IMG2_PATH)]):
    g = load_gray(path)
    res_all = patch_residuals(g)
    sig_all = res_all.reshape(len(res_all), -1).std(axis=1)
    v_max = 0.05
    sel = sig_all < v_max
    if sel.sum() < 4:
        v_adapt = float(np.percentile(sig_all, 25))
        print(f'  [{name}] adaptive v_max -> {v_adapt:.4f}', flush=True)
        sel = sig_all <= v_adapt
        v_max = v_adapt
    res_pool = res_all[sel]
    sig_pool = sig_all[sel]
    lags = range(1, 9)
    ac_pool = np.mean([lag_autocorr(r) for r in res_pool], axis=0)
    ac_all = np.mean([lag_autocorr(r) for r in res_all], axis=0)
    rng = np.random.default_rng(0)
    ac_gauss = np.mean([lag_autocorr(rng.normal(0, sig_pool.mean(),
                                               res_pool.shape[1:]))
                        for _ in range(len(res_pool))], axis=0)
    diff = abs(np.mean(ac_pool) - np.mean(ac_all)) / (np.mean(ac_all) + 1e-12)
    stats[name] = dict(v_max=round(v_max, 4), n_patches=int(sel.sum()),
                       n_all=int(len(res_all)),
                       pool_std_mean=round(float(sig_pool.mean()), 4),
                       all_std_median=round(float(np.median(sig_all)), 4),
                       autocorr_pool=round(float(np.mean(ac_pool)), 4),
                       autocorr_all=round(float(np.mean(ac_all)), 4),
                       autocorr_gauss=round(float(np.mean(ac_gauss)), 4),
                       rel_diff_pct=round(100 * diff, 1))
    print(f'  [{name}] {stats[name]}', flush=True)

    ax = axes[row, 0]
    ax.hist(sig_all, bins=40, color='#546E7A', alpha=.75, label='all patches')
    ax.hist(sig_pool, bins=20, color='#B0413E', alpha=.8, label='selected pool')
    ax.axvline(v_max, color='#B0413E', ls='--', lw=1, label='$v_{max}$')
    ax.set_xlabel('$\\sigma(n_i)$'); ax.set_ylabel('count')
    ax.set_title(f'{name}: std distribution'); ax.legend(fontsize=8)
    ax = axes[row, 1]
    ax.plot(lags, ac_all, 'o-', color='#546E7A', label='all source residuals')
    ax.plot(lags, ac_pool, 's-', color='#B0413E', label='selected noise pool')
    ax.plot(lags, ac_gauss, '^--', color='#8a9a90', label='i.i.d. Gaussian')
    ax.set_xlabel('lag (pixels)'); ax.set_ylabel('mean |autocorrelation|')
    ax.set_title(f'{name}: spatial autocorrelation')
    ax.legend(fontsize=8); ax.grid(alpha=.3)
fig.tight_layout()
fig.savefig(os.path.join(OUT, 'fig_RX_noise_statistics.png'), dpi=300,
            bbox_inches='tight')
plt.close(fig)
with open(os.path.join(OUT, 'noise_statistics.json'), 'w') as f:
    json.dump(stats, f, indent=2)
print('Part C saved. All experiments done.', flush=True)

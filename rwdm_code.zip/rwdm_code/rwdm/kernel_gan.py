# -*- coding: utf-8 -*-
"""
Blur kernel estimation network (Section 3.2, Eq. (4) of the manuscript).

A KernelGAN-style internal-learning GAN that estimates the blur kernel k
present in a real-world remote sensing image (RSI):

    argmin_k || (I_real (x) k) down_s - I_real down_s ||_1      (low-frequency preservation)
           + | 1 - sum(k_ij) |                                  (sum-to-one)
           + | sum(k_ij * m_ij) |                               (boundary penalty)
           + | 1 - D( (I_real (x) k) down_s ) |                 (source-domain consistency / adversarial)

Generator G is a single strided convolution whose weights ARE the kernel k
(convolution + decimation in one step). Discriminator D is a small PatchGAN
producing the D-map shown in Fig. 2 of the manuscript. The adversarial term
is trained with the standard BCE form (equivalent objective to |1 - D(.)|,
numerically more stable).

Kernel estimation is performed on the luminance (grayscale) channel, since the
optical blur kernel is achromatic; the estimated kernel is then applied to all
bands during degradation synthesis.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------------------------------------------------------------
# Generator: the kernel itself
# ----------------------------------------------------------------------
class KernelGenerator(nn.Module):
    """Single strided conv: y = (x (x) k) down_s, weights = blur kernel k."""

    def __init__(self, k_size: int = 13, scale: int = 4):
        super().__init__()
        self.k_size = k_size
        self.scale = scale
        self.conv = nn.Conv2d(1, 1, k_size, stride=scale,
                              padding=k_size // 2, bias=False)
        with torch.no_grad():
            # centre-delta initialisation: G starts as plain decimation
            w = torch.zeros_like(self.conv.weight)
            w[0, 0, k_size // 2, k_size // 2] = 1.0
            self.conv.weight.copy_(w)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.conv(x)

    @property
    def kernel(self) -> torch.Tensor:
        """Current estimate of k, shape (k_size, k_size)."""
        return self.conv.weight[0, 0]


# ----------------------------------------------------------------------
# Discriminator: patch-GAN producing the D-map (Fig. 2)
# ----------------------------------------------------------------------
class PatchDiscriminator(nn.Module):
    def __init__(self, in_ch: int = 1, nf: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(in_ch, nf, 3, 1, 1), nn.LeakyReLU(0.2, True),
            nn.Conv2d(nf, nf, 3, 2, 1), nn.LeakyReLU(0.2, True),
            nn.Conv2d(nf, nf * 2, 3, 1, 1), nn.LeakyReLU(0.2, True),
            nn.Conv2d(nf * 2, nf * 2, 3, 2, 1), nn.LeakyReLU(0.2, True),
            nn.Conv2d(nf * 2, 1, 1, 1, 0), nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# ----------------------------------------------------------------------
# Constraint terms of Eq. (4)
# ----------------------------------------------------------------------
def boundary_mask(k_size: int, border: int = 2) -> torch.Tensor:
    """Binary mask m_ij that is 1 on the outer ring of the kernel."""
    m = torch.zeros(k_size, k_size)
    m[:border, :] = 1.0
    m[-border:, :] = 1.0
    m[:, :border] = 1.0
    m[:, -border:] = 1.0
    return m


def gaussian_kernel_2d(k_size: int, sigma: float) -> torch.Tensor:
    """Isotropic Gaussian kernel (used as the explicit 'ideal' blur kernel)."""
    ax = torch.arange(k_size, dtype=torch.float32) - k_size // 2
    xx, yy = torch.meshgrid(ax, ax, indexing='ij')
    k = torch.exp(-(xx ** 2 + yy ** 2) / (2 * sigma ** 2))
    return k / k.sum()


def ideal_downsample(x: torch.Tensor, scale: int, k_size: int = 13,
                     mode: str = 'explicit') -> torch.Tensor:
    """
    I_real down_s with the 'ideal' blur kernel (term 1 of Eq. (4)).

    mode='explicit': strided convolution with an explicit discrete ideal
        low-pass kernel (Gaussian, sigma = scale/2) on the SAME sampling
        grid as the generator -- aligned by construction (recommended).
    mode='bicubic': torch antialiased bicubic interpolation (KernelGAN's
        choice; note the ~1.5 px grid offset w.r.t. strided convolution).
    """
    if mode == 'explicit':
        k_ideal = gaussian_kernel_2d(k_size, scale / 2.0).to(x.device)
        return F.conv2d(x, k_ideal[None, None], stride=scale,
                        padding=k_size // 2)
    return F.interpolate(x, scale_factor=1.0 / scale, mode='bicubic',
                         align_corners=False, antialias=True)


class KernelEstimationLoss(nn.Module):
    """Weighted sum of the four constraint terms in Eq. (4)."""

    def __init__(self, k_size: int, scale: int,
                 w_rec: float = 5.0, w_sum: float = 0.2,
                 w_bound: float = 0.1, border: int = 2,
                 target_mode: str = 'explicit'):
        super().__init__()
        self.scale = scale
        self.w_rec, self.w_sum, self.w_bound = w_rec, w_sum, w_bound
        self.k_size = k_size
        self.target_mode = target_mode
        self.register_buffer('mask', boundary_mask(k_size, border))

    def forward(self, G: KernelGenerator, x: torch.Tensor,
                fake: torch.Tensor) -> dict:
        k = G.kernel
        target = ideal_downsample(x, self.scale, self.k_size,
                                  self.target_mode)              # I_real down_s
        loss_rec = F.l1_loss(fake, target)                       # term 1
        loss_sum = torch.abs(1.0 - k.sum())                      # term 2
        loss_bound = torch.abs((k * self.mask).sum())            # term 3
        total_constraints = (self.w_rec * loss_rec +
                             self.w_sum * loss_sum +
                             self.w_bound * loss_bound)
        return {'rec': loss_rec, 'sum': loss_sum,
                'bound': loss_bound, 'constraints': total_constraints}


# ----------------------------------------------------------------------
# Trainer
# ----------------------------------------------------------------------
class KernelGANTrainer:
    """
    Internal-learning optimisation of Eq. (4) on ONE real-world RSI
    (grayscale, float32 in [0, 1], shape H x W).
    """

    def __init__(self, img_gray: np.ndarray, k_size: int = 13, scale: int = 4,
                 crop: int = 128, n_iter: int = 6000, lr: float = 2e-3,
                 w_rec: float = 5.0, w_sum: float = 0.2,
                 w_bound: float = 0.1, w_adv: float = 0.05,
                 border: int = 2, target_mode: str = 'explicit',
                 device: str = 'cpu', seed: int = 0):
        torch.manual_seed(seed)
        np.random.seed(seed)
        self.device = device
        self.scale, self.crop, self.n_iter = scale, crop, n_iter
        self.w_adv = w_adv

        self.img = torch.from_numpy(img_gray[None, None]).float().to(device)
        self.G = KernelGenerator(k_size, scale).to(device)
        self.D = PatchDiscriminator().to(device)
        self.crit = KernelEstimationLoss(k_size, scale, w_rec, w_sum,
                                         w_bound, border, target_mode).to(device)
        self.opt_G = torch.optim.Adam(self.G.parameters(), lr=lr, betas=(0.5, 0.999))
        self.opt_D = torch.optim.Adam(self.D.parameters(), lr=lr, betas=(0.5, 0.999))
        self.sched_G = torch.optim.lr_scheduler.StepLR(self.opt_G, step_size=n_iter // 3, gamma=0.5)
        self.sched_D = torch.optim.lr_scheduler.StepLR(self.opt_D, step_size=n_iter // 3, gamma=0.5)
        self.bce = nn.BCELoss()
        self.snap_every = 200
        self.history = {'snapshots': []}
        self.history.update({k: [] for k in
                             ['rec', 'sum', 'bound', 'adv', 'd_real', 'd_fake']})

    def _rand_crop(self, img: torch.Tensor, size: int) -> torch.Tensor:
        _, _, h, w = img.shape
        i = np.random.randint(0, h - size + 1)
        j = np.random.randint(0, w - size + 1)
        return img[:, :, i:i + size, j:j + size]

    def train(self, verbose: bool = True) -> np.ndarray:
        son_size = self.crop // self.scale
        mother = ideal_downsample(self.img, self.scale,
                                  self.crit.k_size,
                                  self.crit.target_mode)   # I_real down_s
        for it in range(1, self.n_iter + 1):
            father_crop = self._rand_crop(self.img, self.crop)
            real_crop = self._rand_crop(mother, son_size)

            # ---- update D: real patch vs fake patch (Fig. 2) ----
            with torch.no_grad():
                fake = self.G(father_crop)
            d_real = self.D(real_crop)
            d_fake = self.D(fake)
            loss_D = (self.bce(d_real, torch.ones_like(d_real)) +
                      self.bce(d_fake, torch.zeros_like(d_fake))) * 0.5
            self.opt_D.zero_grad(); loss_D.backward(); self.opt_D.step()

            # ---- update G: Eq. (4) = constraints + adversarial term ----
            fake = self.G(father_crop)
            parts = self.crit(self.G, father_crop, fake)
            d_fake_for_g = self.D(fake)
            loss_adv = self.bce(d_fake_for_g, torch.ones_like(d_fake_for_g))
            loss_G = parts['constraints'] + self.w_adv * loss_adv
            self.opt_G.zero_grad(); loss_G.backward(); self.opt_G.step()
            self.sched_G.step(); self.sched_D.step()

            for key, val in [('rec', parts['rec']), ('sum', parts['sum']),
                             ('bound', parts['bound']), ('adv', loss_adv),
                             ('d_real', d_real.mean()), ('d_fake', d_fake_for_g.mean())]:
                self.history[key].append(float(val.detach().cpu()))
            if it % self.snap_every == 0:
                self.history['snapshots'].append(
                    (it, self.G.kernel.detach().cpu().numpy().copy()))
            if verbose and (it % max(1, self.n_iter // 10) == 0 or it == 1):
                print(f'  iter {it:4d}/{self.n_iter}  rec={parts["rec"]:.4f}  '
                      f'sum={parts["sum"]:.4f}  bound={parts["bound"]:.4f}  '
                      f'adv={loss_adv:.4f}  D(real)={d_real.mean():.3f}  '
                      f'D(fake)={d_fake_for_g.mean():.3f}')

        # post-hoc physical constraints: non-negativity + unit sum
        k = self.G.kernel.detach().cpu().numpy()
        k = np.clip(k, 0.0, None)
        k /= (k.sum() + 1e-12)
        return k


def estimate_kernel(img_gray: np.ndarray, **kwargs) -> tuple:
    """Convenience wrapper: returns (kernel, loss_history)."""
    trainer = KernelGANTrainer(img_gray, **kwargs)
    k = trainer.train(verbose=kwargs.get('verbose', True))
    return k, trainer.history

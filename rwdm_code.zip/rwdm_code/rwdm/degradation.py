# -*- coding: utf-8 -*-
"""
RWDM degradation synthesis chain (Section 3.2, Eqs. (2)-(3) and Fig. 1).

    I_HR = I_real down_c                              (Eq. (2): clean HR target)
    I_LR = (I_HR (x) k) down_s + n                    (Eq. (3): realistic LR)

The clean HR target is obtained by down-sampling the real-world RSI (factor c);
the realistic LR is produced by convolving I_HR with a blur kernel k drawn from
the estimated kernel dataset, decimating by the scale factor s, and adding a
noise patch n drawn from the collected noise pool.
"""

import cv2
import numpy as np
import torch
import torch.nn.functional as F

from .noise_pool import NoisePool


# ----------------------------------------------------------------------
# Basic operators
# ----------------------------------------------------------------------
def ideal_downsample(img: np.ndarray, factor: int) -> np.ndarray:
    """Antialiased down-sampling by an integer factor (area interpolation)."""
    if factor == 1:
        return img.copy()
    h, w = img.shape[:2]
    return cv2.resize(img, (w // factor, h // factor),
                      interpolation=cv2.INTER_AREA)


def conv2d_same(img: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    """Convolve HxWxC image with a 2-D kernel (reflect padding, same size)."""
    k = torch.from_numpy(kernel[None, None].astype(np.float32))
    x = torch.from_numpy(img.transpose(2, 0, 1)[None].astype(np.float32))
    pad = kernel.shape[0] // 2
    x = F.pad(x, (pad, pad, pad, pad), mode='reflect')
    y = F.conv2d(x, k.expand(img.shape[2], 1, -1, -1), groups=img.shape[2])
    return y[0].numpy().transpose(1, 2, 0)


def anisotropic_gaussian_kernel(k_size: int, sigma_x: float, sigma_y: float,
                                theta_deg: float) -> np.ndarray:
    """Anisotropic Gaussian PSF (used to synthesise ground truth in the demo)."""
    ax = np.arange(k_size) - k_size // 2
    xx, yy = np.meshgrid(ax, ax)
    th = np.deg2rad(theta_deg)
    xg = xx * np.cos(th) + yy * np.sin(th)
    yg = -xx * np.sin(th) + yy * np.cos(th)
    k = np.exp(-(xg ** 2 / (2 * sigma_x ** 2) + yg ** 2 / (2 * sigma_y ** 2)))
    return (k / k.sum()).astype(np.float32)


# ----------------------------------------------------------------------
# RWDM synthesiser
# ----------------------------------------------------------------------
class RWDM:
    """Real-World Degradation Model: kernels dataset + noise pool -> LR-HR pairs."""

    def __init__(self, kernels: np.ndarray, noise_pool: NoisePool,
                 scale: int = 4, factor_c: int = 1, seed: int = 0):
        self.kernels = kernels            # (N, k, k) estimated kernel dataset
        self.noise_pool = noise_pool
        self.scale = scale                # s in Eq. (3)
        self.factor_c = factor_c          # c in Eq. (2)
        self.rng = np.random.default_rng(seed)

    def clean_hr(self, i_real: np.ndarray) -> np.ndarray:
        """Eq. (2): I_HR = I_real down_c."""
        return ideal_downsample(i_real, self.factor_c)

    def degrade_hr(self, i_hr: np.ndarray,
                   kernel: np.ndarray = None,
                   noise: np.ndarray = None) -> np.ndarray:
        """Eq. (3): I_LR = (I_HR (x) k) down_s + n."""
        if kernel is None:
            kernel = self.kernels[self.rng.integers(len(self.kernels))]
        blurred = conv2d_same(i_hr, kernel)                 # I_HR (x) k
        lr = blurred[::self.scale, ::self.scale]            # down_s (decimation)
        if noise is None:
            noise = self.noise_pool.sample(lr.shape[0], lr.shape[1],
                                           lr.shape[2], self.rng)
        lr = np.clip(lr + noise, 0.0, 1.0)                  # + n
        return lr.astype(np.float32)

    def synthesize_pair(self, i_real: np.ndarray):
        """Full RWDM chain on one real-world RSI: returns (I_LR, I_HR)."""
        i_hr = self.clean_hr(i_real)
        i_lr = self.degrade_hr(i_hr)
        return i_lr, i_hr

# -*- coding: utf-8 -*-
"""
Noise patch extraction (Section 3.2, Eq. (5) and Fig. 3 of the manuscript).

Noise patches are collected from the source (real-world) dataset by a sliding
window. Each image patch is converted into a noise patch by subtracting its
mean (Fig. 3, 'Subtract mean'), and is kept only when its variance satisfies

    sigma(n_i) < v_max        (Eq. (5))

so that the collected noise patches carry rich stochastic information while
edge/texture-dominated patches are rejected.
"""

import numpy as np


def extract_noise_patches(img: np.ndarray,
                          patch_size: int = 40,
                          stride: int = None,
                          v_max: float = 0.05,
                          max_patches: int = 3000,
                          per_channel_mean: bool = True,
                          seed: int = 0):
    """
    Parameters
    ----------
    img : HxW or HxWxC float array in [0, 1]
    patch_size : side length of the square patch
    stride : sliding-window stride (default = patch_size // 2)
    v_max : maximum allowed standard deviation sigma(n_i), Eq. (5)
    max_patches : cap on the pool size
    per_channel_mean : subtract the mean of each channel separately
    Returns
    -------
    pool : (N, patch_size, patch_size, C) float32 noise patches
    sigmas : (N,) std sigma(n_i) of every accepted patch
    all_sigmas : std of every visited patch (for the v_max histogram)
    """
    rng = np.random.default_rng(seed)
    if stride is None:
        stride = patch_size // 2
    if img.ndim == 2:
        img = img[..., None]
    h, w, c = img.shape

    pool, sigmas, all_sigmas = [], [], []
    for i in range(0, h - patch_size + 1, stride):
        for j in range(0, w - patch_size + 1, stride):
            patch = img[i:i + patch_size, j:j + patch_size].astype(np.float32)
            if per_channel_mean:
                noise = patch - patch.mean(axis=(0, 1), keepdims=True)
            else:
                noise = patch - patch.mean()
            sigma = float(noise.std())
            all_sigmas.append(sigma)
            if sigma < v_max:                       # Eq. (5)
                pool.append(noise.astype(np.float32))
                sigmas.append(sigma)

    if not pool:                                    # adaptive fallback for v_max
        v_adapt = float(np.percentile(all_sigmas, 25))
        print(f'  [noise_pool] no patch satisfies sigma < {v_max}; '
              f'adapting v_max to 25th percentile = {v_adapt:.4f}')
        for i in range(0, h - patch_size + 1, stride):
            for j in range(0, w - patch_size + 1, stride):
                patch = img[i:i + patch_size, j:j + patch_size].astype(np.float32)
                noise = (patch - patch.mean(axis=(0, 1), keepdims=True)
                         if per_channel_mean else patch - patch.mean())
                if float(noise.std()) < v_adapt:
                    pool.append(noise.astype(np.float32))
                    sigmas.append(float(noise.std()))

    if len(pool) > max_patches:                     # keep information-rich subset
        idx = rng.choice(len(pool), max_patches, replace=False)
        pool = [pool[t] for t in idx]
        sigmas = [sigmas[t] for t in idx]

    pool = (np.stack(pool) if pool else
            np.zeros((0, patch_size, patch_size, c), np.float32))
    return pool, np.asarray(sigmas, np.float32), np.asarray(all_sigmas, np.float32)


class NoisePool:
    """Noise pool assembled from several real-world RSIs."""

    def __init__(self):
        self._patches = []

    def add_image(self, img: np.ndarray, **kwargs):
        pool, _, _ = extract_noise_patches(img, **kwargs)
        if len(pool):
            self._patches.append(pool)
        return len(pool)

    @property
    def patches(self) -> np.ndarray:
        return (np.concatenate(self._patches, axis=0) if self._patches else
                np.zeros((0,)))

    def sample(self, out_h: int, out_w: int, channels: int,
               rng: np.random.Generator) -> np.ndarray:
        """Draw one patch and fit it to (out_h, out_w, channels)."""
        import cv2
        patches = self.patches
        assert len(patches), 'noise pool is empty'
        p = patches[rng.integers(len(patches))]
        if p.shape[-1] != channels:                # gray pool -> replicate
            p = np.repeat(p.mean(-1, keepdims=True), channels, axis=-1)
        if p.shape[0] != out_h or p.shape[1] != out_w:
            p = cv2.resize(p, (out_w, out_h), interpolation=cv2.INTER_LINEAR)
        return p.astype(np.float32)

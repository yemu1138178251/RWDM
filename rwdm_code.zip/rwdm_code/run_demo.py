# -*- coding: utf-8 -*-
"""
End-to-end demo of the RWDM framework (Section 3.2 of the manuscript).

Pipeline (per input image):
  1) obtain a 'real-world RSI' (synthetic scene, or real images via --data_dir)
  2) Eq. (4): estimate the blur kernel with the GAN-based kernel estimation
     network (low-frequency preservation + sum-to-one + boundary penalty
     + discriminator consistency)
  3) Eq. (5): collect noise patches under the variance constraint
  4) Eqs. (2)-(3): synthesise a realistic LR-HR training pair

All figures are saved at 300 dpi; arrays are saved as .npy.
Usage:
    python run_demo.py                                  # synthetic demo
    python run_demo.py --data_dir /path/to/real_RSIs    # every image in folder
"""
import argparse
import json
import os

import cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

from rwdm import (KernelGANTrainer, NoisePool, extract_noise_patches, RWDM)

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, 'results')
os.makedirs(OUT, exist_ok=True)


# ----------------------------------------------------------------------
# synthetic stand-in for a real-world RSI (sharp scene + sensor noise)
# ----------------------------------------------------------------------
def fractal_texture(size, octaves=8, seed=0):
    """Multi-octave value noise with ~1/f spectrum (natural-like statistics)."""
    rng = np.random.default_rng(seed)
    img = np.zeros((size, size), np.float32)
    amp, total = 1.0, 0.0
    for o in range(octaves):
        g = min(4 * 2 ** o, size)
        layer = cv2.resize(rng.random((g, g)).astype(np.float32),
                           (size, size), interpolation=cv2.INTER_CUBIC)
        img += amp * layer
        total += amp
        amp *= 0.6
    img /= total
    return (img - img.min()) / (np.ptp(img) + 1e-12)


def make_synthetic_rsi(size=256, noise_std=2.0 / 255, seed=0):
    """Sharp pseudo satellite scene + sensor noise -> 'real-world RSI'."""
    rng = np.random.default_rng(seed)
    base = np.dstack([fractal_texture(size, seed=seed + c) * 0.6 + 0.2
                      for c in range(3)]).astype(np.float32)
    for _ in range(22):                      # buildings with sharp edges
        x, y = rng.integers(10, size - 60, 2)
        w, h = rng.integers(10, 45, 2)
        base[y:y + h, x:x + w] *= rng.uniform(0.5, 1.3)
        cv2.rectangle(base, (x, y), (x + w, y + h), 0.1, 1)
    for _ in range(5):                       # roads
        p1 = tuple(rng.integers(0, size, 2))
        p2 = tuple(rng.integers(0, size, 2))
        cv2.line(base, p1, p2, 0.1, int(rng.integers(2, 4)))
    noisy = np.clip(base + rng.normal(0, noise_std, base.shape), 0, 1)
    return noisy.astype(np.float32)


def to_gray(img):
    return cv2.cvtColor(img, cv2.COLOR_RGB2GRAY).astype(np.float32)


# ----------------------------------------------------------------------
# per-image pipeline
# ----------------------------------------------------------------------
def run_pipeline(img_real, name, args, out_dir):
    """Run steps 2-4 of the RWDM on one image; save figures + arrays."""
    os.makedirs(out_dir, exist_ok=True)
    H, W = img_real.shape[:2]
    crop = min(args.crop, H // 2, W // 2)          # adapt to small images
    n_patch = min(args.noise_patch, H // 4, W // 4)
    print(f'\n===== {name}  ({H}x{W})  crop={crop}, noise_patch={n_patch} =====')
    cv2.imwrite(os.path.join(out_dir, 'real_RSI.png'),
                cv2.cvtColor((img_real * 255).astype(np.uint8),
                             cv2.COLOR_RGB2BGR))

    # ---------- step 2: Eq. (4) blur kernel estimation ----------
    print('[Step 2] Blur kernel estimation (Eq. 4) ...')
    trainer = KernelGANTrainer(to_gray(img_real), k_size=args.k_size,
                               scale=args.scale, crop=crop,
                               n_iter=args.n_iter, device=args.device)
    k_est = trainer.train(verbose=True)
    np.save(os.path.join(out_dir, 'estimated_kernel.npy'), k_est)
    ring = np.ones_like(k_est)
    ring[2:-2, 2:-2] = 0
    bound_mass = float((k_est * ring).sum())
    print('estimated kernel:  size = %dx%d,  sum = %.4f,  min = %.5f,  '
          'boundary mass = %.4f'
          % (k_est.shape[0], k_est.shape[1], k_est.sum(), k_est.min(),
             bound_mass))

    # ---------- step 3: Eq. (5) noise patch collection ----------
    print('[Step 3] Noise patch collection (Eq. 5) ...')
    pool, sig_accept, sig_all = extract_noise_patches(
        img_real, patch_size=n_patch, v_max=args.v_max)
    print(f'visited patches: {len(sig_all)}, accepted: {len(pool)} '
          f'(v_max = {args.v_max})')
    noise_pool = NoisePool()
    noise_pool._patches.append(pool)
    np.save(os.path.join(out_dir, 'noise_pool.npy'), pool)

    # ---------- step 4: Eqs. (2)-(3) LR-HR pair synthesis ----------
    print('[Step 4] RWDM pair synthesis (Eqs. 2-3) ...')
    rwdm = RWDM(k_est[None], noise_pool, scale=args.scale,
                factor_c=args.factor_c)
    i_lr, i_hr = rwdm.synthesize_pair(img_real)
    print('clean HR:', i_hr.shape, ' realistic LR:', i_lr.shape)
    cv2.imwrite(os.path.join(out_dir, 'HR.png'),
                cv2.cvtColor((i_hr * 255).astype(np.uint8), cv2.COLOR_RGB2BGR))
    cv2.imwrite(os.path.join(out_dir, 'LR_realistic.png'),
                cv2.cvtColor((i_lr * 255).astype(np.uint8), cv2.COLOR_RGB2BGR))

    # ---------- figures (300 dpi) ----------
    # (a) loss curves of Eq. (4)
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.2))
    h = trainer.history
    axes[0].plot(h['rec'], label='low-freq preservation')
    axes[0].plot(h['sum'], label='sum-to-one')
    axes[0].plot(h['bound'], label='boundary penalty')
    axes[0].set_title('Constraint terms of Eq. (4)')
    axes[0].set_xlabel('iteration')
    axes[0].legend(); axes[0].grid(alpha=.3)
    axes[1].plot(h['adv'], label='adversarial')
    axes[1].plot(h['d_real'], label='D(real)')
    axes[1].plot(h['d_fake'], label='D(fake)')
    axes[1].set_title('Discriminator consistency')
    axes[1].set_xlabel('iteration')
    axes[1].legend(); axes[1].grid(alpha=.3)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, 'fig_loss_curves.png'), dpi=300)
    plt.close(fig)

    # (b) estimated blur kernel: heatmap + 3-D surface
    fig = plt.figure(figsize=(9, 3.8))
    ax1 = fig.add_subplot(1, 2, 1)
    im = ax1.imshow(k_est, cmap='viridis')
    ax1.set_title('Estimated blur kernel $k$')
    ax1.axis('off')
    fig.colorbar(im, ax=ax1, fraction=0.046)
    ax2 = fig.add_subplot(1, 2, 2, projection='3d')
    xs, ys = np.meshgrid(np.arange(k_est.shape[1]), np.arange(k_est.shape[0]))
    ax2.plot_surface(xs, ys, k_est, cmap='viridis', edgecolor='none')
    ax2.set_title('Kernel surface')
    ax2.set_xticks([]); ax2.set_yticks([])
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, 'fig_kernel.png'), dpi=300)
    plt.close(fig)

    # (c) noise pool statistics
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.4))
    axes[0].hist(sig_all, bins=60, color='#546E7A', alpha=.85)
    axes[0].axvline(args.v_max, color='#B0413E', ls='--',
                    label='$v_{max}$ (Eq. 5)')
    axes[0].set_xlabel('$\\sigma(n_i)$')
    axes[0].set_ylabel('count')
    axes[0].set_title('Variance constraint')
    axes[0].legend()
    axes[1].set_title('Collected noise patches (x5)')
    axes[1].axis('off')
    if len(pool) >= 4:
        strip = np.concatenate(
            [np.repeat(pool[k], 3, axis=-1) if pool[k].shape[-1] == 1
             else pool[k] for k in range(4)], axis=1)
        axes[1].imshow(np.clip(strip * 5 + 0.5, 0, 1))
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, 'fig_noise_pool.png'), dpi=300)
    plt.close(fig)

    # (d) RWDM chain visualisation
    fig, axes = plt.subplots(1, 3, figsize=(11, 3.8))
    axes[0].imshow(img_real)
    axes[0].set_title('Real RSI $I_{real}$')
    axes[1].imshow(i_hr)
    axes[1].set_title('Clean HR (Eq. 2)')
    axes[2].imshow(cv2.resize(i_lr, (i_lr.shape[1] * args.scale,
                                     i_lr.shape[0] * args.scale),
                              interpolation=cv2.INTER_NEAREST))
    axes[2].set_title('Realistic LR x%d (Eq. 3)' % args.scale)
    for ax in axes:
        ax.axis('off')
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, 'fig_rwdm_chain.png'), dpi=300)
    plt.close(fig)

    return {'image': name, 'shape': [H, W],
            'kernel_size': int(k_est.shape[0]),
            'kernel_sum': float(k_est.sum()),
            'kernel_min': float(k_est.min()),
            'boundary_mass': bound_mass,
            'noise_patches': int(len(pool)),
            'lr_shape': list(i_lr.shape)}


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data_dir', type=str, default=None,
                    help='folder of real RSIs (uses synthetic demo if omitted)')
    ap.add_argument('--k_size', type=int, default=13, help='blur kernel size')
    ap.add_argument('--scale', type=int, default=4, help='s in Eq. (3)')
    ap.add_argument('--factor_c', type=int, default=1, help='c in Eq. (2)')
    ap.add_argument('--n_iter', type=int, default=3000,
                    help='optimisation iterations of Eq. (4)')
    ap.add_argument('--crop', type=int, default=96, help='crop size for Eq. (4)')
    ap.add_argument('--noise_patch', type=int, default=64)
    ap.add_argument('--v_max', type=float, default=0.05, help='v_max in Eq. (5)')
    ap.add_argument('--device', type=str, default='cpu')
    args = ap.parse_args()
    print('device:', args.device)

    summaries = []
    if args.data_dir:
        files = sorted(f for f in os.listdir(args.data_dir)
                       if f.lower().endswith(('.png', '.jpg', '.tif')))
        assert files, 'no images found'
        for f in files:
            img = cv2.cvtColor(cv2.imread(os.path.join(args.data_dir, f)),
                               cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
            stem = os.path.splitext(f)[0]
            summaries.append(run_pipeline(img, stem, args,
                                          os.path.join(OUT, stem)))
    else:
        summaries.append(run_pipeline(make_synthetic_rsi(256), 'synthetic',
                                      args, os.path.join(OUT, 'synthetic')))

    with open(os.path.join(OUT, 'summary.json'), 'w') as f:
        json.dump({'params': vars(args), 'runs': summaries}, f, indent=2)
    print('\nAll results saved to:', OUT)


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
"""RWDM: Real-World Degradation Model for remote sensing image SR (Sec. 3.2)."""
from .kernel_gan import KernelGANTrainer, estimate_kernel
from .noise_pool import NoisePool, extract_noise_patches
from .degradation import (RWDM, ideal_downsample, conv2d_same,
                          anisotropic_gaussian_kernel)
